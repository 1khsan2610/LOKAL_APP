import 'package:url_launcher/url_launcher.dart';

Future<bool> openUrl(String url) async {
  final uri = Uri.parse(url);
  return await launchUrl(uri, mode: LaunchMode.externalApplication);
}
